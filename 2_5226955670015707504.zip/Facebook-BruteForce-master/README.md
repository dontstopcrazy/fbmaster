# Facebook-BruteForce
```
Bruteforce attack for Facebook Account
```

## Install Requirements(Linux)
```
>> apt-get install git python3 python3-pip python python-pip
```

## Run commands one by one
```
>> git clone https://github.com/IAmBlackHacker/Facebook-BruteForce
>> cd Facebook-BruteForce
>> pip3 install requests bs4
>> pip install mechanize
>> python3 fb.py or python fb2.py
```

## Screenshots
![CAPTURE 1](https://github.com/IAmBlackHacker/Facebook-BruteForce/blob/master/Screenshots/Capture1.JPG)
![CAPTURE 1](https://github.com/IAmBlackHacker/Facebook-BruteForce/blob/master/Screenshots/Capture2.JPG)
![CAPTURE 1](https://github.com/IAmBlackHacker/Facebook-BruteForce/blob/master/Screenshots/Capture3.JPG)

## Protection Against Attacker
* Use Strong Password(which contains standard password chars + longest as possible)
* Use 2F Authentication.
* Make location based login(+browser based).

## Explore More in Hacking ...
https://www.facebook.com/B14CKH4K3R/

~~~
Happy Hacking Day ! (Please do not spam it, It's Just For Knowledge ...).
~~~
